﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlytkaNaciskowa2 : MonoBehaviour
{
    bool nacisk = false;
    public GameObject plotekPierwszy;

    void OnTriggerEnter(Collider trigger)
    {
        if (!nacisk)
        {
            plotekPierwszy.transform.Rotate(0f,0f, 90f);
            plotekPierwszy.transform.position += new Vector3(-1.15f, -0.9f, -0.6f);
            
            transform.position += new Vector3(0f, -0.11f);
            
            nacisk = true;
        }
    }

    void OnTriggerExit(Collider trigger)
    {
        if (nacisk)
        {
            plotekPierwszy.transform.Rotate(0f, 0f, -90f);
            plotekPierwszy.transform.position += new Vector3(1.15f, 0.9f, 0.6f);

            transform.position += new Vector3(0f, 0.11f);
            
            nacisk = false;
        }
    }
}

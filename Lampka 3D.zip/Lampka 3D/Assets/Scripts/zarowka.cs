﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zarowka : MonoBehaviour
{
    public Light zZarowki;
    public Light naZarowke;
    bool nacisk = true;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.L) && !nacisk)
        {
            zZarowki.enabled = false;
            naZarowke.enabled = false;
            nacisk = true;
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.L) && nacisk)
            {
                zZarowki.enabled = true;
                naZarowke.enabled = true;
                nacisk = false;
            }
        }
    }
}

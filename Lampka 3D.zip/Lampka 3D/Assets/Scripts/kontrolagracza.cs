﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class kontrolagracza : MonoBehaviour
{
    public float predkosc = 10f;
    public float silaSkoku = 150f;
    bool czyNaZiemi;
    Rigidbody rigidbody;

    private void Start()
    {
        rigidbody = GetComponent<Rigidbody>();
    }
    void FixedUpdate()
    {

        rigidbody.AddForce(Input.GetAxis("Vertical") * predkosc, 0f, -Input.GetAxis("Horizontal") * predkosc);

        if ((czyNaZiemi) && (Input.GetKey(KeyCode.Space)))
        {
            Debug.Log("jump");
            rigidbody.AddForce(0f,silaSkoku,0f);
            czyNaZiemi = false;   
        }

        CheckPosition();
    }

    void OnCollisionStay(Collision other)
    {
        foreach (ContactPoint temp in other.contacts)
        {
            if ((temp.normal.y > 0.7))
            {
                czyNaZiemi = true;
            }
        }
    }

    void CheckPosition()
    {
        if (transform.position.y <= -10) transform.position = new Vector3(6f, 2f, -7.5f);
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlytkaNaciskowa : MonoBehaviour
{
    bool nacisk = false;
    bool nacisk2 = true;
    public Light swiatloPadajace;
    public Light swiatloOdbite;
    public float time = 0;

        void OnTriggerEnter(Collider trigger)
    {
        if (!nacisk)
        {
            transform.position += new Vector3(0f, -0.11f, 0f);
            nacisk = true;

            if (!nacisk2)
            {
                swiatloPadajace.enabled = false;
                swiatloOdbite.enabled = false;
                nacisk2 = true;
            }
            else
            {
                swiatloPadajace.enabled = true;
                swiatloOdbite.enabled = true;
                nacisk2 = false;
            }
        }          
    }

    void OnTriggerExit(Collider trigger)
    {
        if (nacisk)
        {
            transform.position += new Vector3(0f, +0.11f, 0f);
            nacisk = false;
        }
    }

    IEnumerator opoznienie()
    {
        yield return new WaitForSeconds (5f);

    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WidzeniePrzezSciany : MonoBehaviour
{
    private int layerMask = 1 << 8;
    private List<Transform> hiddenObject;
    private float stopienPrzezroczystosci = 0.2F;
    public GameObject player;

    // Start is called before the first frame update
    void Start()
    {
        hiddenObject = new List<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 obnizenie = new Vector3(0f, -0.55f, 0);
        Vector3 direction = (player.transform.position + obnizenie) - transform.position;
        float odleglosc = Vector3.Distance(player.transform.position, transform.position);

        RaycastHit[] hits = Physics.RaycastAll(transform.position, direction, odleglosc, layerMask);
        Debug.DrawRay(transform.position, direction, Color.red);

        for (int i = 0; i < hits.Length; i++)
        {
            RaycastHit hit = hits[i];
            Transform currentHit = hit.transform;

            if (!hiddenObject.Contains(currentHit))
            {
                hiddenObject.Add(currentHit);
                Renderer rend = hit.transform.GetComponent<Renderer>();

                if (rend)
                {
                    rend.material.shader = Shader.Find("Transparent/Diffuse");
                    Color tempColor = rend.material.color;
                    tempColor.a = stopienPrzezroczystosci;
                    rend.material.color = tempColor;
                }
            }
        }

        for (int i = 0; i < hiddenObject.Count; i++)
        {

            bool isHit = false;
            for (int j = 0; j < hits.Length; j++)
            {
                if (hiddenObject[i] == hits[j].transform)
                {
                    isHit = true;
                    break;
                }
            }

            if (!isHit)
            {
                Renderer rend = hiddenObject[i].transform.GetComponent<Renderer>();
                rend.material.shader = Shader.Find("Standard (Specular setup)");
                hiddenObject.RemoveAt(i);
            }
        }
    }
}

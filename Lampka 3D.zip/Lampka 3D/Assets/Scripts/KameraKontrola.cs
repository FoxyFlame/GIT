﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KameraKontrola : MonoBehaviour
{
    public Transform player;
    public float odleglosc = 8;
    int pozycjaKamery = 0;
    bool naciskPlus = false;
    bool naciskMinus = false;

    // Update is called once per frame
    void Update()
    {
        Rigidbody rigidbody = player.GetComponent<Rigidbody>();

        /*if (Input.GetKeyDown(KeyCode.Q))
        {
            if (pozycjaKamery == 3) pozycjaKamery = 0;
            else pozycjaKamery++;
        }
        if (Input.GetKeyDown(KeyCode.E))
        {
            if (pozycjaKamery == 0) pozycjaKamery = 3;
            else pozycjaKamery--;
        }*/

        Vector3 vector = new Vector3(0f, odleglosc, 0f);
        Vector3 pozycjaX = new Vector3(odleglosc*2, 0f, 0f);
        //Vector3 pozycjaZ = new Vector3(0f, 0f, odleglosc*2);

        if (pozycjaKamery == 0) vector = vector - pozycjaX ;
        //if (pozycjaKamery == 1) vector = vector + pozycjaZ ;
        //if (pozycjaKamery == 2) vector = vector + pozycjaX ;
        //if (pozycjaKamery == 3) vector = vector - pozycjaZ ;

        if (Input.GetKeyDown(KeyCode.KeypadPlus) && !naciskPlus)
        {
            odleglosc++;
            naciskPlus = true;
        }
        else
        {
            naciskPlus = false;
        }

        if (Input.GetKeyDown(KeyCode.KeypadMinus) && !naciskMinus)
        {
            odleglosc--;
            naciskMinus = true;
        }
        else
        {
            naciskMinus = false;
        }

        float velocity = rigidbody.velocity.sqrMagnitude;
        vector = vector * (1f + velocity / 150f);

        Vector3 nowaPozycja = player.position + vector;

        transform.position = Vector3.Lerp(transform.position, nowaPozycja, Time.deltaTime/(1.2f));
        transform.LookAt(player);

        
    }
}

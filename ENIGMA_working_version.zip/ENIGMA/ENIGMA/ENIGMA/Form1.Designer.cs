﻿namespace ENIGMA
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelPierscien1 = new System.Windows.Forms.Label();
            this.ScrollBarPierscien1 = new System.Windows.Forms.VScrollBar();
            this.labelPierscien2 = new System.Windows.Forms.Label();
            this.labelPierscien3 = new System.Windows.Forms.Label();
            this.ScrollBarPierscien2 = new System.Windows.Forms.VScrollBar();
            this.ScrollBarPierscien3 = new System.Windows.Forms.VScrollBar();
            this.label_Q = new System.Windows.Forms.Label();
            this.label_W = new System.Windows.Forms.Label();
            this.label_E = new System.Windows.Forms.Label();
            this.label_R = new System.Windows.Forms.Label();
            this.label_T = new System.Windows.Forms.Label();
            this.label_Y = new System.Windows.Forms.Label();
            this.label_U = new System.Windows.Forms.Label();
            this.label_I = new System.Windows.Forms.Label();
            this.label_O = new System.Windows.Forms.Label();
            this.label_P = new System.Windows.Forms.Label();
            this.label_A = new System.Windows.Forms.Label();
            this.label_S = new System.Windows.Forms.Label();
            this.label_D = new System.Windows.Forms.Label();
            this.label_F = new System.Windows.Forms.Label();
            this.label_G = new System.Windows.Forms.Label();
            this.label_H = new System.Windows.Forms.Label();
            this.label_J = new System.Windows.Forms.Label();
            this.label_K = new System.Windows.Forms.Label();
            this.label_L = new System.Windows.Forms.Label();
            this.label_Z = new System.Windows.Forms.Label();
            this.label_X = new System.Windows.Forms.Label();
            this.label_C = new System.Windows.Forms.Label();
            this.label_V = new System.Windows.Forms.Label();
            this.label_B = new System.Windows.Forms.Label();
            this.label_N = new System.Windows.Forms.Label();
            this.label_M = new System.Windows.Forms.Label();
            this.label_1 = new System.Windows.Forms.Label();
            this.label_2 = new System.Windows.Forms.Label();
            this.label_3 = new System.Windows.Forms.Label();
            this.label_4 = new System.Windows.Forms.Label();
            this.label_5 = new System.Windows.Forms.Label();
            this.label_6 = new System.Windows.Forms.Label();
            this.label_7 = new System.Windows.Forms.Label();
            this.label_8 = new System.Windows.Forms.Label();
            this.label_9 = new System.Windows.Forms.Label();
            this.label_0 = new System.Windows.Forms.Label();
            this.label_Ź = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label_SPACE = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.uSTAWIENIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uSTAWIENIAPIERSCIENIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dODATKOWASZYFRACJAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sZYFRCEZARAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wLACZWYLACZToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uSTAWIENIACEZARAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelPierscien1
            // 
            this.labelPierscien1.Location = new System.Drawing.Point(35, 44);
            this.labelPierscien1.Name = "labelPierscien1";
            this.labelPierscien1.Size = new System.Drawing.Size(34, 12);
            this.labelPierscien1.TabIndex = 0;
            this.labelPierscien1.Text = "1";
            this.labelPierscien1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ScrollBarPierscien1
            // 
            this.ScrollBarPierscien1.LargeChange = 1;
            this.ScrollBarPierscien1.Location = new System.Drawing.Point(35, 26);
            this.ScrollBarPierscien1.Maximum = 37;
            this.ScrollBarPierscien1.Minimum = 1;
            this.ScrollBarPierscien1.Name = "ScrollBarPierscien1";
            this.ScrollBarPierscien1.Size = new System.Drawing.Size(34, 49);
            this.ScrollBarPierscien1.TabIndex = 1;
            this.ScrollBarPierscien1.Value = 1;
            this.ScrollBarPierscien1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.ScrollBarPierscien1_Scroll);
            // 
            // labelPierscien2
            // 
            this.labelPierscien2.Location = new System.Drawing.Point(107, 45);
            this.labelPierscien2.Name = "labelPierscien2";
            this.labelPierscien2.Size = new System.Drawing.Size(34, 12);
            this.labelPierscien2.TabIndex = 2;
            this.labelPierscien2.Text = "1";
            this.labelPierscien2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelPierscien3
            // 
            this.labelPierscien3.Location = new System.Drawing.Point(181, 45);
            this.labelPierscien3.Name = "labelPierscien3";
            this.labelPierscien3.Size = new System.Drawing.Size(34, 12);
            this.labelPierscien3.TabIndex = 3;
            this.labelPierscien3.Text = "1";
            this.labelPierscien3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ScrollBarPierscien2
            // 
            this.ScrollBarPierscien2.LargeChange = 1;
            this.ScrollBarPierscien2.Location = new System.Drawing.Point(107, 27);
            this.ScrollBarPierscien2.Maximum = 37;
            this.ScrollBarPierscien2.Minimum = 1;
            this.ScrollBarPierscien2.Name = "ScrollBarPierscien2";
            this.ScrollBarPierscien2.Size = new System.Drawing.Size(34, 48);
            this.ScrollBarPierscien2.TabIndex = 4;
            this.ScrollBarPierscien2.Value = 1;
            this.ScrollBarPierscien2.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBar2_Scroll);
            // 
            // ScrollBarPierscien3
            // 
            this.ScrollBarPierscien3.LargeChange = 1;
            this.ScrollBarPierscien3.Location = new System.Drawing.Point(181, 27);
            this.ScrollBarPierscien3.Maximum = 37;
            this.ScrollBarPierscien3.Minimum = 1;
            this.ScrollBarPierscien3.Name = "ScrollBarPierscien3";
            this.ScrollBarPierscien3.Size = new System.Drawing.Size(34, 48);
            this.ScrollBarPierscien3.TabIndex = 5;
            this.ScrollBarPierscien3.Value = 1;
            this.ScrollBarPierscien3.Scroll += new System.Windows.Forms.ScrollEventHandler(this.ScrollBarPierscien3_Scroll);
            // 
            // label_Q
            // 
            this.label_Q.BackColor = System.Drawing.Color.Gray;
            this.label_Q.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_Q.Location = new System.Drawing.Point(68, 33);
            this.label_Q.Name = "label_Q";
            this.label_Q.Size = new System.Drawing.Size(35, 35);
            this.label_Q.TabIndex = 7;
            this.label_Q.Text = "2";
            this.label_Q.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_W
            // 
            this.label_W.BackColor = System.Drawing.Color.Gray;
            this.label_W.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_W.Location = new System.Drawing.Point(109, 77);
            this.label_W.Name = "label_W";
            this.label_W.Size = new System.Drawing.Size(35, 35);
            this.label_W.TabIndex = 8;
            this.label_W.Text = "E";
            this.label_W.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_E
            // 
            this.label_E.BackColor = System.Drawing.Color.Gray;
            this.label_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_E.Location = new System.Drawing.Point(355, 33);
            this.label_E.Name = "label_E";
            this.label_E.Size = new System.Drawing.Size(35, 35);
            this.label_E.TabIndex = 9;
            this.label_E.Text = "9";
            this.label_E.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_R
            // 
            this.label_R.BackColor = System.Drawing.Color.Gray;
            this.label_R.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_R.Location = new System.Drawing.Point(314, 165);
            this.label_R.Name = "label_R";
            this.label_R.Size = new System.Drawing.Size(35, 35);
            this.label_R.TabIndex = 10;
            this.label_R.Text = "M";
            this.label_R.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_T
            // 
            this.label_T.BackColor = System.Drawing.Color.Gray;
            this.label_T.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_T.Location = new System.Drawing.Point(355, 77);
            this.label_T.Name = "label_T";
            this.label_T.Size = new System.Drawing.Size(35, 35);
            this.label_T.TabIndex = 11;
            this.label_T.Text = "O";
            this.label_T.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Y
            // 
            this.label_Y.BackColor = System.Drawing.Color.Gray;
            this.label_Y.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_Y.Location = new System.Drawing.Point(130, 121);
            this.label_Y.Name = "label_Y";
            this.label_Y.Size = new System.Drawing.Size(35, 35);
            this.label_Y.TabIndex = 12;
            this.label_Y.Text = "D";
            this.label_Y.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_U
            // 
            this.label_U.BackColor = System.Drawing.Color.Gray;
            this.label_U.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_U.Location = new System.Drawing.Point(376, 121);
            this.label_U.Name = "label_U";
            this.label_U.Size = new System.Drawing.Size(35, 35);
            this.label_U.TabIndex = 13;
            this.label_U.Text = "L";
            this.label_U.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_I
            // 
            this.label_I.BackColor = System.Drawing.Color.Gray;
            this.label_I.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_I.Location = new System.Drawing.Point(191, 165);
            this.label_I.Name = "label_I";
            this.label_I.Size = new System.Drawing.Size(35, 35);
            this.label_I.TabIndex = 14;
            this.label_I.Text = "V";
            this.label_I.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_O
            // 
            this.label_O.BackColor = System.Drawing.Color.Gray;
            this.label_O.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_O.Location = new System.Drawing.Point(396, 77);
            this.label_O.Name = "label_O";
            this.label_O.Size = new System.Drawing.Size(35, 35);
            this.label_O.TabIndex = 15;
            this.label_O.Text = "P";
            this.label_O.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_P
            // 
            this.label_P.BackColor = System.Drawing.Color.Gray;
            this.label_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_P.Location = new System.Drawing.Point(273, 33);
            this.label_P.Name = "label_P";
            this.label_P.Size = new System.Drawing.Size(35, 35);
            this.label_P.TabIndex = 16;
            this.label_P.Text = "7";
            this.label_P.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_A
            // 
            this.label_A.BackColor = System.Drawing.Color.Gray;
            this.label_A.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_A.Location = new System.Drawing.Point(150, 33);
            this.label_A.Name = "label_A";
            this.label_A.Size = new System.Drawing.Size(35, 35);
            this.label_A.TabIndex = 17;
            this.label_A.Text = "4";
            this.label_A.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_S
            // 
            this.label_S.BackColor = System.Drawing.Color.Gray;
            this.label_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_S.Location = new System.Drawing.Point(273, 165);
            this.label_S.Name = "label_S";
            this.label_S.Size = new System.Drawing.Size(35, 35);
            this.label_S.TabIndex = 18;
            this.label_S.Text = "N";
            this.label_S.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_D
            // 
            this.label_D.BackColor = System.Drawing.Color.Gray;
            this.label_D.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_D.Location = new System.Drawing.Point(396, 33);
            this.label_D.Name = "label_D";
            this.label_D.Size = new System.Drawing.Size(35, 35);
            this.label_D.TabIndex = 19;
            this.label_D.Text = "0";
            this.label_D.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_F
            // 
            this.label_F.BackColor = System.Drawing.Color.Gray;
            this.label_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_F.Location = new System.Drawing.Point(314, 77);
            this.label_F.Name = "label_F";
            this.label_F.Size = new System.Drawing.Size(35, 35);
            this.label_F.TabIndex = 20;
            this.label_F.Text = "I";
            this.label_F.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_G
            // 
            this.label_G.BackColor = System.Drawing.Color.Gray;
            this.label_G.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_G.Location = new System.Drawing.Point(109, 165);
            this.label_G.Name = "label_G";
            this.label_G.Size = new System.Drawing.Size(35, 35);
            this.label_G.TabIndex = 21;
            this.label_G.Text = "X";
            this.label_G.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_H
            // 
            this.label_H.BackColor = System.Drawing.Color.Gray;
            this.label_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_H.Location = new System.Drawing.Point(68, 77);
            this.label_H.Name = "label_H";
            this.label_H.Size = new System.Drawing.Size(35, 35);
            this.label_H.TabIndex = 22;
            this.label_H.Text = "W";
            this.label_H.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_J
            // 
            this.label_J.BackColor = System.Drawing.Color.Gray;
            this.label_J.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_J.Location = new System.Drawing.Point(273, 77);
            this.label_J.Name = "label_J";
            this.label_J.Size = new System.Drawing.Size(35, 35);
            this.label_J.TabIndex = 23;
            this.label_J.Text = "U";
            this.label_J.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_K
            // 
            this.label_K.BackColor = System.Drawing.Color.Gray;
            this.label_K.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_K.Location = new System.Drawing.Point(191, 77);
            this.label_K.Name = "label_K";
            this.label_K.Size = new System.Drawing.Size(35, 35);
            this.label_K.TabIndex = 24;
            this.label_K.Text = "T";
            this.label_K.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_L
            // 
            this.label_L.BackColor = System.Drawing.Color.Gray;
            this.label_L.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_L.Location = new System.Drawing.Point(89, 121);
            this.label_L.Name = "label_L";
            this.label_L.Size = new System.Drawing.Size(35, 35);
            this.label_L.TabIndex = 25;
            this.label_L.Text = "S";
            this.label_L.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Z
            // 
            this.label_Z.BackColor = System.Drawing.Color.Gray;
            this.label_Z.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_Z.Location = new System.Drawing.Point(232, 165);
            this.label_Z.Name = "label_Z";
            this.label_Z.Size = new System.Drawing.Size(35, 35);
            this.label_Z.TabIndex = 26;
            this.label_Z.Text = "B";
            this.label_Z.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_X
            // 
            this.label_X.BackColor = System.Drawing.Color.Gray;
            this.label_X.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_X.Location = new System.Drawing.Point(253, 121);
            this.label_X.Name = "label_X";
            this.label_X.Size = new System.Drawing.Size(35, 35);
            this.label_X.TabIndex = 27;
            this.label_X.Text = "H";
            this.label_X.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_C
            // 
            this.label_C.BackColor = System.Drawing.Color.Gray;
            this.label_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_C.Location = new System.Drawing.Point(232, 77);
            this.label_C.Name = "label_C";
            this.label_C.Size = new System.Drawing.Size(35, 35);
            this.label_C.TabIndex = 28;
            this.label_C.Text = "Y";
            this.label_C.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_V
            // 
            this.label_V.BackColor = System.Drawing.Color.Gray;
            this.label_V.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_V.Location = new System.Drawing.Point(335, 121);
            this.label_V.Name = "label_V";
            this.label_V.Size = new System.Drawing.Size(35, 35);
            this.label_V.TabIndex = 29;
            this.label_V.Text = "K";
            this.label_V.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_B
            // 
            this.label_B.BackColor = System.Drawing.Color.Gray;
            this.label_B.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_B.Location = new System.Drawing.Point(68, 165);
            this.label_B.Name = "label_B";
            this.label_B.Size = new System.Drawing.Size(35, 35);
            this.label_B.TabIndex = 30;
            this.label_B.Text = "Z";
            this.label_B.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_N
            // 
            this.label_N.BackColor = System.Drawing.Color.Gray;
            this.label_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_N.Location = new System.Drawing.Point(27, 77);
            this.label_N.Name = "label_N";
            this.label_N.Size = new System.Drawing.Size(35, 35);
            this.label_N.TabIndex = 31;
            this.label_N.Text = "Q";
            this.label_N.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_M
            // 
            this.label_M.BackColor = System.Drawing.Color.Gray;
            this.label_M.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_M.Location = new System.Drawing.Point(150, 77);
            this.label_M.Name = "label_M";
            this.label_M.Size = new System.Drawing.Size(35, 35);
            this.label_M.TabIndex = 32;
            this.label_M.Text = "R";
            this.label_M.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_1
            // 
            this.label_1.BackColor = System.Drawing.Color.Gray;
            this.label_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_1.Location = new System.Drawing.Point(150, 165);
            this.label_1.Name = "label_1";
            this.label_1.Size = new System.Drawing.Size(35, 35);
            this.label_1.TabIndex = 42;
            this.label_1.Text = "C";
            this.label_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_2
            // 
            this.label_2.BackColor = System.Drawing.Color.Gray;
            this.label_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_2.Location = new System.Drawing.Point(212, 121);
            this.label_2.Name = "label_2";
            this.label_2.Size = new System.Drawing.Size(35, 35);
            this.label_2.TabIndex = 43;
            this.label_2.Text = "G";
            this.label_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_3
            // 
            this.label_3.BackColor = System.Drawing.Color.Gray;
            this.label_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_3.Location = new System.Drawing.Point(27, 33);
            this.label_3.Name = "label_3";
            this.label_3.Size = new System.Drawing.Size(35, 35);
            this.label_3.TabIndex = 44;
            this.label_3.Text = "1";
            this.label_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_4
            // 
            this.label_4.BackColor = System.Drawing.Color.Gray;
            this.label_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_4.Location = new System.Drawing.Point(109, 33);
            this.label_4.Name = "label_4";
            this.label_4.Size = new System.Drawing.Size(35, 35);
            this.label_4.TabIndex = 45;
            this.label_4.Text = "3";
            this.label_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_5
            // 
            this.label_5.BackColor = System.Drawing.Color.Gray;
            this.label_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_5.Location = new System.Drawing.Point(191, 33);
            this.label_5.Name = "label_5";
            this.label_5.Size = new System.Drawing.Size(35, 35);
            this.label_5.TabIndex = 46;
            this.label_5.Text = "5";
            this.label_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_6
            // 
            this.label_6.BackColor = System.Drawing.Color.Gray;
            this.label_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_6.Location = new System.Drawing.Point(314, 33);
            this.label_6.Name = "label_6";
            this.label_6.Size = new System.Drawing.Size(35, 35);
            this.label_6.TabIndex = 47;
            this.label_6.Text = "8";
            this.label_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_7
            // 
            this.label_7.BackColor = System.Drawing.Color.Gray;
            this.label_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_7.Location = new System.Drawing.Point(171, 121);
            this.label_7.Name = "label_7";
            this.label_7.Size = new System.Drawing.Size(35, 35);
            this.label_7.TabIndex = 48;
            this.label_7.Text = "F";
            this.label_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_8
            // 
            this.label_8.BackColor = System.Drawing.Color.Gray;
            this.label_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_8.Location = new System.Drawing.Point(294, 121);
            this.label_8.Name = "label_8";
            this.label_8.Size = new System.Drawing.Size(35, 35);
            this.label_8.TabIndex = 49;
            this.label_8.Text = "J";
            this.label_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_9
            // 
            this.label_9.BackColor = System.Drawing.Color.Gray;
            this.label_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_9.Location = new System.Drawing.Point(48, 121);
            this.label_9.Name = "label_9";
            this.label_9.Size = new System.Drawing.Size(35, 35);
            this.label_9.TabIndex = 50;
            this.label_9.Text = "A";
            this.label_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_0
            // 
            this.label_0.BackColor = System.Drawing.Color.Gray;
            this.label_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_0.Location = new System.Drawing.Point(232, 33);
            this.label_0.Name = "label_0";
            this.label_0.Size = new System.Drawing.Size(35, 35);
            this.label_0.TabIndex = 51;
            this.label_0.Text = "6";
            this.label_0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_Ź
            // 
            this.label_Ź.BackColor = System.Drawing.Color.Gray;
            this.label_Ź.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_Ź.Location = new System.Drawing.Point(583, 278);
            this.label_Ź.Name = "label_Ź";
            this.label_Ź.Size = new System.Drawing.Size(35, 35);
            this.label_Ź.TabIndex = 58;
            this.label_Ź.Text = "Ź";
            this.label_Ź.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label_SPACE);
            this.groupBox1.Controls.Add(this.label_3);
            this.groupBox1.Controls.Add(this.label_Q);
            this.groupBox1.Controls.Add(this.label_4);
            this.groupBox1.Controls.Add(this.label_A);
            this.groupBox1.Controls.Add(this.label_5);
            this.groupBox1.Controls.Add(this.label_0);
            this.groupBox1.Controls.Add(this.label_P);
            this.groupBox1.Controls.Add(this.label_6);
            this.groupBox1.Controls.Add(this.label_E);
            this.groupBox1.Controls.Add(this.label_D);
            this.groupBox1.Controls.Add(this.label_9);
            this.groupBox1.Controls.Add(this.label_Z);
            this.groupBox1.Controls.Add(this.label_1);
            this.groupBox1.Controls.Add(this.label_Y);
            this.groupBox1.Controls.Add(this.label_W);
            this.groupBox1.Controls.Add(this.label_7);
            this.groupBox1.Controls.Add(this.label_2);
            this.groupBox1.Controls.Add(this.label_X);
            this.groupBox1.Controls.Add(this.label_F);
            this.groupBox1.Controls.Add(this.label_8);
            this.groupBox1.Controls.Add(this.label_V);
            this.groupBox1.Controls.Add(this.label_U);
            this.groupBox1.Controls.Add(this.label_R);
            this.groupBox1.Controls.Add(this.label_S);
            this.groupBox1.Controls.Add(this.label_T);
            this.groupBox1.Controls.Add(this.label_O);
            this.groupBox1.Controls.Add(this.label_N);
            this.groupBox1.Controls.Add(this.label_M);
            this.groupBox1.Controls.Add(this.label_L);
            this.groupBox1.Controls.Add(this.label_K);
            this.groupBox1.Controls.Add(this.label_J);
            this.groupBox1.Controls.Add(this.label_I);
            this.groupBox1.Controls.Add(this.label_H);
            this.groupBox1.Controls.Add(this.label_G);
            this.groupBox1.Controls.Add(this.label_C);
            this.groupBox1.Controls.Add(this.label_B);
            this.groupBox1.Location = new System.Drawing.Point(12, 38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(459, 269);
            this.groupBox1.TabIndex = 61;
            this.groupBox1.TabStop = false;
            // 
            // label_SPACE
            // 
            this.label_SPACE.BackColor = System.Drawing.Color.Gray;
            this.label_SPACE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_SPACE.Location = new System.Drawing.Point(27, 206);
            this.label_SPACE.Name = "label_SPACE";
            this.label_SPACE.Size = new System.Drawing.Size(404, 35);
            this.label_SPACE.TabIndex = 70;
            this.label_SPACE.Text = "______";
            this.label_SPACE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.labelPierscien1);
            this.groupBox2.Controls.Add(this.labelPierscien2);
            this.groupBox2.Controls.Add(this.labelPierscien3);
            this.groupBox2.Controls.Add(this.ScrollBarPierscien2);
            this.groupBox2.Controls.Add(this.ScrollBarPierscien3);
            this.groupBox2.Controls.Add(this.ScrollBarPierscien1);
            this.groupBox2.Location = new System.Drawing.Point(477, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(243, 114);
            this.groupBox2.TabIndex = 63;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "KLUCZ PIERSCIENI";
            // 
            // button1
            // 
            this.button1.CausesValidation = false;
            this.button1.Location = new System.Drawing.Point(477, 132);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(243, 23);
            this.button1.TabIndex = 64;
            this.button1.TabStop = false;
            this.button1.Text = "USTAWIENIA PIERSCIENI";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightGreen;
            this.button2.Location = new System.Drawing.Point(477, 182);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(243, 23);
            this.button2.TabIndex = 65;
            this.button2.TabStop = false;
            this.button2.Text = "SZYFROWANIE";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(477, 166);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 13);
            this.label1.TabIndex = 66;
            this.label1.Text = "AKTUALNY STAN ENIGMY:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(477, 219);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 13);
            this.label2.TabIndex = 67;
            this.label2.Text = "SZYFRACJA DODATKOWA (CEZAR):";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(676, 218);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(44, 17);
            this.checkBox1.TabIndex = 68;
            this.checkBox1.TabStop = false;
            this.checkBox1.Text = "NIE";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(477, 241);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(243, 23);
            this.button3.TabIndex = 69;
            this.button3.TabStop = false;
            this.button3.Text = "USTAWIENIA CEZARA";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uSTAWIENIAToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(734, 24);
            this.menuStrip1.TabIndex = 70;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // uSTAWIENIAToolStripMenuItem
            // 
            this.uSTAWIENIAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uSTAWIENIAPIERSCIENIToolStripMenuItem,
            this.dODATKOWASZYFRACJAToolStripMenuItem});
            this.uSTAWIENIAToolStripMenuItem.Name = "uSTAWIENIAToolStripMenuItem";
            this.uSTAWIENIAToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.uSTAWIENIAToolStripMenuItem.Text = "USTAWIENIA";
            // 
            // uSTAWIENIAPIERSCIENIToolStripMenuItem
            // 
            this.uSTAWIENIAPIERSCIENIToolStripMenuItem.Name = "uSTAWIENIAPIERSCIENIToolStripMenuItem";
            this.uSTAWIENIAPIERSCIENIToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.uSTAWIENIAPIERSCIENIToolStripMenuItem.Text = "USTAWIENIA PIERSCIENI";
            this.uSTAWIENIAPIERSCIENIToolStripMenuItem.Click += new System.EventHandler(this.uSTAWIENIAPIERSCIENIToolStripMenuItem_Click);
            // 
            // dODATKOWASZYFRACJAToolStripMenuItem
            // 
            this.dODATKOWASZYFRACJAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sZYFRCEZARAToolStripMenuItem});
            this.dODATKOWASZYFRACJAToolStripMenuItem.Name = "dODATKOWASZYFRACJAToolStripMenuItem";
            this.dODATKOWASZYFRACJAToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.dODATKOWASZYFRACJAToolStripMenuItem.Text = "DODATKOWA SZYFRACJA";
            // 
            // sZYFRCEZARAToolStripMenuItem
            // 
            this.sZYFRCEZARAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wLACZWYLACZToolStripMenuItem,
            this.uSTAWIENIACEZARAToolStripMenuItem});
            this.sZYFRCEZARAToolStripMenuItem.Name = "sZYFRCEZARAToolStripMenuItem";
            this.sZYFRCEZARAToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sZYFRCEZARAToolStripMenuItem.Text = "SZYFR CEZARA";
            // 
            // wLACZWYLACZToolStripMenuItem
            // 
            this.wLACZWYLACZToolStripMenuItem.Name = "wLACZWYLACZToolStripMenuItem";
            this.wLACZWYLACZToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.wLACZWYLACZToolStripMenuItem.Text = "WLACZ / WYLACZ";
            // 
            // uSTAWIENIACEZARAToolStripMenuItem
            // 
            this.uSTAWIENIACEZARAToolStripMenuItem.Name = "uSTAWIENIACEZARAToolStripMenuItem";
            this.uSTAWIENIACEZARAToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.uSTAWIENIACEZARAToolStripMenuItem.Text = "USTAWIENIA CEZARA";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(734, 322);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label_Ź);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelPierscien1;
        private System.Windows.Forms.Label labelPierscien2;
        private System.Windows.Forms.Label labelPierscien3;
        private System.Windows.Forms.VScrollBar ScrollBarPierscien2;
        private System.Windows.Forms.VScrollBar ScrollBarPierscien3;
        private System.Windows.Forms.Label label_Q;
        private System.Windows.Forms.Label label_W;
        private System.Windows.Forms.Label label_E;
        private System.Windows.Forms.Label label_R;
        private System.Windows.Forms.Label label_T;
        private System.Windows.Forms.Label label_Y;
        private System.Windows.Forms.Label label_U;
        private System.Windows.Forms.Label label_I;
        private System.Windows.Forms.Label label_O;
        private System.Windows.Forms.Label label_P;
        private System.Windows.Forms.Label label_A;
        private System.Windows.Forms.Label label_S;
        private System.Windows.Forms.Label label_D;
        private System.Windows.Forms.Label label_F;
        private System.Windows.Forms.Label label_G;
        private System.Windows.Forms.Label label_H;
        private System.Windows.Forms.Label label_J;
        private System.Windows.Forms.Label label_K;
        private System.Windows.Forms.Label label_L;
        private System.Windows.Forms.Label label_Z;
        private System.Windows.Forms.Label label_X;
        private System.Windows.Forms.Label label_C;
        private System.Windows.Forms.Label label_V;
        private System.Windows.Forms.Label label_B;
        private System.Windows.Forms.Label label_N;
        private System.Windows.Forms.Label label_M;
        private System.Windows.Forms.Label label_1;
        private System.Windows.Forms.Label label_2;
        private System.Windows.Forms.Label label_3;
        private System.Windows.Forms.Label label_4;
        private System.Windows.Forms.Label label_5;
        private System.Windows.Forms.Label label_6;
        private System.Windows.Forms.Label label_7;
        private System.Windows.Forms.Label label_8;
        private System.Windows.Forms.Label label_9;
        private System.Windows.Forms.Label label_0;
        private System.Windows.Forms.Label label_Ź;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.VScrollBar ScrollBarPierscien1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label_SPACE;
        public System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem uSTAWIENIAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uSTAWIENIAPIERSCIENIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dODATKOWASZYFRACJAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sZYFRCEZARAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wLACZWYLACZToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uSTAWIENIACEZARAToolStripMenuItem;
    }
}


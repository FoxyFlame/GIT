﻿using NUnit.Framework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ENIGMA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            KeyPreview = true;
        }

        public List<Keys> KlawiszePodst = new List<Keys>(new Keys[] { Keys.Space, Keys.D1, Keys.D2, Keys.D3, Keys.D4, Keys.D5, Keys.D6, Keys.D7, Keys.D8, Keys.D9, Keys.D0, Keys.A, Keys.B, Keys.C, Keys.D, Keys.E, Keys.F, Keys.G, Keys.H, Keys.I, Keys.J, Keys.K, Keys.L, Keys.M, Keys.N, Keys.O, Keys.P, Keys.Q, Keys.R, Keys.S, Keys.T, Keys.U, Keys.V, Keys.W, Keys.X, Keys.Y, Keys.Z });
        public List<int> PierścienPierwszy = new List<int>(new int[] { 20, 5, 25, 13, 8, 21, 32, 34, 15, 36, 12, 1, 14, 7, 31, 33, 2, 22, 29, 24, 3, 4, 16, 35, 11, 28, 6, 0, 17, 23, 18, 27, 9, 30, 19, 26, 10 });
        public List<int> PierścienDrugi = new List<int>(new int[] { 8, 33, 12, 36, 5, 23, 16, 35, 4, 28, 17, 21, 11, 20, 27, 29, 6, 15, 34, 26, 1, 7, 32, 10, 31, 22, 19, 3, 25, 18, 0, 2, 14, 24, 9, 30, 13 });
        public List<int> PierścienTrzeci = new List<int>(new int[] { 2, 15, 28, 10, 14, 19, 4, 20, 35, 0, 29, 5, 33, 9, 32, 23, 3, 30, 34, 18, 11, 24, 1, 25, 8, 36, 26, 16, 31, 7, 12, 21, 17, 27, 13, 22, 6 });

        int wartoscScrollBar1 = 1, wartoscScrollBar2 = 1, wartoscScrollBar3 = 1;
        bool Nacisk = false;

        int przechowanie_i_keydown;

        public void CofnieciePierscienPierwszy()
        {
            int temp = PierścienPierwszy[36];
            PierścienPierwszy.RemoveAt(36);
            PierścienPierwszy.Insert(0, temp);
            wartoscScrollBar1 = ScrollBarPierscien1.Value;
        }

        public void CofnieciePierscienDrugi()
        {
            int temp = PierścienDrugi[36];
            PierścienDrugi.RemoveAt(36);
            PierścienDrugi.Insert(0, temp);
            wartoscScrollBar2 = ScrollBarPierscien2.Value;
        }

        public void CofnieciePierscienTrzeci()
        {
            int temp = PierścienTrzeci[36];
            PierścienTrzeci.RemoveAt(36);
            PierścienTrzeci.Insert(0, temp);
            wartoscScrollBar3 = ScrollBarPierscien3.Value;
        }

        public void Cofniecie()
        {
            if (ScrollBarPierscien1.Value == 1)
            {
                if (ScrollBarPierscien2.Value == 1)
                {
                    if (ScrollBarPierscien1.Value == 1)
                    {
                        labelPierscien1.Text = (ScrollBarPierscien1.Value = 37).ToString();
                        labelPierscien2.Text = (ScrollBarPierscien2.Value = 37).ToString();
                        labelPierscien3.Text = (ScrollBarPierscien3.Value = 37).ToString();

                        CofnieciePierscienPierwszy();
                        CofnieciePierscienDrugi();
                        CofnieciePierscienTrzeci();
                    }
                    else
                    {
                        labelPierscien1.Text = (ScrollBarPierscien1.Value = 37).ToString();
                        labelPierscien2.Text = (ScrollBarPierscien2.Value = 37).ToString();
                        labelPierscien3.Text = (ScrollBarPierscien3.Value -= 1).ToString();

                        CofnieciePierscienPierwszy();
                        CofnieciePierscienDrugi();
                        CofnieciePierscienTrzeci();
                    }
                }
                else
                {
                    labelPierscien1.Text = (ScrollBarPierscien1.Value = 37).ToString();
                    labelPierscien2.Text = (ScrollBarPierscien2.Value -= 1).ToString();

                    CofnieciePierscienPierwszy();
                    CofnieciePierscienDrugi();
                }
            }
            else
            {
                labelPierscien1.Text = (ScrollBarPierscien1.Value -= 1).ToString();

                CofnieciePierscienPierwszy();
            }
        }

        public void PrzesunieciePierscienPierwszy()
        {
            int temp = PierścienPierwszy[0];
            PierścienPierwszy.RemoveAt(0);
            PierścienPierwszy.Add(temp);
            wartoscScrollBar1 = ScrollBarPierscien1.Value;
        }

        public void PrzesunieciePierscienDrugi()
        {
            int temp = PierścienDrugi[0];
            PierścienDrugi.RemoveAt(0);
            PierścienDrugi.Add(temp);
            wartoscScrollBar2 = ScrollBarPierscien2.Value;
        }

        public void PrzesunieciePierscienTrzeci()
        {
            int temp = PierścienTrzeci[0];
            PierścienTrzeci.RemoveAt(0);
            PierścienTrzeci.Add(temp);
            wartoscScrollBar3 = ScrollBarPierscien3.Value;
        }

        public void Przesuniecie()
        {
            if (ScrollBarPierscien1.Value >= 36)
            {
                if (ScrollBarPierscien2.Value >= 36)
                {
                    if (ScrollBarPierscien3.Value >= 36)
                    {
                        labelPierscien1.Text = (ScrollBarPierscien1.Value = 1).ToString();
                        labelPierscien2.Text = (ScrollBarPierscien2.Value = 1).ToString();
                        labelPierscien3.Text = (ScrollBarPierscien3.Value = 1).ToString();

                        PrzesunieciePierscienPierwszy();
                        PrzesunieciePierscienDrugi();
                        PrzesunieciePierscienTrzeci();
                    }
                    else
                    {
                        labelPierscien1.Text = (ScrollBarPierscien1.Value = 1).ToString();
                        labelPierscien2.Text = (ScrollBarPierscien2.Value = 1).ToString();
                        labelPierscien3.Text = (ScrollBarPierscien3.Value += 1).ToString();

                        PrzesunieciePierscienPierwszy();
                        PrzesunieciePierscienDrugi();
                        PrzesunieciePierscienTrzeci();
                    }
                }
                else
                {
                    labelPierscien1.Text = (ScrollBarPierscien1.Value = 1).ToString();
                    labelPierscien2.Text = (ScrollBarPierscien2.Value += 1).ToString();

                    PrzesunieciePierscienPierwszy();
                    PrzesunieciePierscienDrugi();
                }
            }
            else
            {
                labelPierscien1.Text = (ScrollBarPierscien1.Value += 1).ToString();

                PrzesunieciePierscienPierwszy();
            }
        }

        public void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            if (!Nacisk)
            {
                if (e.KeyCode != Keys.Space)
                {
                    Nacisk = true;

                    for (int i = 0; i < 37; i++)
                    {
                        if (e.Alt && e.KeyCode == KlawiszePodst[i])
                        {
                            // groupBox1.Controls[i].BackColor = Color.Yellow;
                        }
                        else
                        {
                            if (e.KeyCode == KlawiszePodst[i])
                            {
                                if (button2.Text == "SZYFROWANIE")
                                {
                                    groupBox1.Controls[PierścienTrzeci[PierścienDrugi[PierścienPierwszy[i]]]].BackColor = Color.Yellow;
                                    Przesuniecie();
                                }
                                else
                                {
                                    for (int j = 0; j < 37; j++)
                                    {
                                        if (PierścienTrzeci[j] == i)
                                            for (int k = 0; k < 37; k++)
                                            {
                                                if (PierścienDrugi[k] == j)
                                                    for (int z = 0; z < 37; z++)
                                                    {
                                                        if (PierścienPierwszy[z] == k) groupBox1.Controls[z].BackColor = Color.Yellow;
                                                    }
                                            }
                                    }
                                    Cofniecie();
                                }
                                przechowanie_i_keydown = i;
                            }
                        }
                    }
                }
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            for (int i = 0; i < 37; i++)
            {
                if (e.KeyCode == KlawiszePodst[przechowanie_i_keydown])
                {
                    groupBox1.Controls[i].BackColor = Color.Gray;
                    Nacisk = false;
                }
            }
        }

        private void ScrollBarPierscien1_Scroll(object sender, ScrollEventArgs e)
        {
            if (ScrollBarPierscien1.Value > wartoscScrollBar1)
            {
                PrzesunieciePierscienPierwszy();
            }
            else
            {
                if (ScrollBarPierscien1.Value < wartoscScrollBar1)
                {
                    CofnieciePierscienPierwszy();
                }
            }

            labelPierscien1.Text = ScrollBarPierscien1.Value.ToString();
        }

        private void vScrollBar2_Scroll(object sender, ScrollEventArgs e)
        {
            labelPierscien2.Text = ScrollBarPierscien2.Value.ToString();

            if (ScrollBarPierscien2.Value > wartoscScrollBar2)
            {
                PrzesunieciePierscienDrugi();
            }
            else
            {
                if (ScrollBarPierscien2.Value < wartoscScrollBar2)
                {
                    CofnieciePierscienDrugi();
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                button3.Enabled = true;
                checkBox1.Text = "TAK";
            }
            else
            {
                checkBox1.Text = "NIE";
                button3.Enabled = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 cezar = new Form3();
            cezar.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (button2.Text == "DESZYFROWANIE")
            {
                button2.Text = "SZYFROWANIE";
                button2.BackColor = Color.LightGreen;
                checkBox1.Enabled = true;
                Przesuniecie();
            }
            else
            {
                button2.Text = "DESZYFROWANIE";
                button2.BackColor = Color.LightSalmon;
                checkBox1.Enabled = false;
                Cofniecie();
            }
        }

        private void uSTAWIENIAPIERSCIENIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 ustawienia = new Form2();

            ustawienia.richTextBox2.Text = "";
            ustawienia.richTextBox3.Text = "";
            ustawienia.richTextBox4.Text = "";

            for (int i = 0; i < 37; i++)
            {
                ustawienia.richTextBox2.Text = ustawienia.richTextBox2.Text + PierścienPierwszy[i] + Environment.NewLine;
                ustawienia.richTextBox3.Text = ustawienia.richTextBox3.Text + PierścienDrugi[i] + Environment.NewLine;
                ustawienia.richTextBox4.Text = ustawienia.richTextBox4.Text + PierścienTrzeci[i] + Environment.NewLine;
            }
            if (ustawienia.ShowDialog() == DialogResult.OK)
            {
                PierścienPierwszy.Clear();
                PierścienDrugi.Clear();
                PierścienTrzeci.Clear();

                for (int i = 0; i < 37; i++)
                {
                    PierścienPierwszy.Add(int.Parse(ustawienia.richTextBox2.Lines[i]));
                    PierścienDrugi.Add(int.Parse(ustawienia.richTextBox3.Lines[i]));
                    PierścienTrzeci.Add(int.Parse(ustawienia.richTextBox4.Lines[i]));
                }

                labelPierscien1.Text = (ScrollBarPierscien1.Value = 1).ToString();
                labelPierscien2.Text = (ScrollBarPierscien2.Value = 1).ToString();
                labelPierscien3.Text = (ScrollBarPierscien3.Value = 1).ToString();

                wartoscScrollBar1 = 1;
                wartoscScrollBar2 = 1;
                wartoscScrollBar3 = 1;

                button1.CausesValidation = false;
            }

            private void ScrollBarPierscien3_Scroll(object sender, ScrollEventArgs e)
            {
                labelPierscien3.Text = ScrollBarPierscien3.Value.ToString();

                if (ScrollBarPierscien3.Value > wartoscScrollBar3)
                {
                    PrzesunieciePierscienTrzeci();
                }
                else
                {
                    if (ScrollBarPierscien3.Value < wartoscScrollBar3)
                    {
                        CofnieciePierscienTrzeci();
                    }
                }
            }

            private void button1_Click_1(object sender, EventArgs e)
            {
                Form2 ustawienia = new Form2();

                ustawienia.richTextBox2.Text = "";
                ustawienia.richTextBox3.Text = "";
                ustawienia.richTextBox4.Text = "";

                for (int i = 0; i < 37; i++)
                {
                    ustawienia.richTextBox2.Text = ustawienia.richTextBox2.Text + PierścienPierwszy[i] + Environment.NewLine;
                    ustawienia.richTextBox3.Text = ustawienia.richTextBox3.Text + PierścienDrugi[i] + Environment.NewLine;
                    ustawienia.richTextBox4.Text = ustawienia.richTextBox4.Text + PierścienTrzeci[i] + Environment.NewLine;
                }
                if (ustawienia.ShowDialog() == DialogResult.OK)
                {
                    PierścienPierwszy.Clear();
                    PierścienDrugi.Clear();
                    PierścienTrzeci.Clear();

                    for (int i = 0; i < 37; i++)
                    {
                        PierścienPierwszy.Add(int.Parse(ustawienia.richTextBox2.Lines[i]));
                        PierścienDrugi.Add(int.Parse(ustawienia.richTextBox3.Lines[i]));
                        PierścienTrzeci.Add(int.Parse(ustawienia.richTextBox4.Lines[i]));
                    }

                    labelPierscien1.Text = (ScrollBarPierscien1.Value = 1).ToString();
                    labelPierscien2.Text = (ScrollBarPierscien2.Value = 1).ToString();
                    labelPierscien3.Text = (ScrollBarPierscien3.Value = 1).ToString();

                    wartoscScrollBar1 = 1;
                    wartoscScrollBar2 = 1;
                    wartoscScrollBar3 = 1;

                    button1.CausesValidation = false;
                }
            }
        }
    }
}

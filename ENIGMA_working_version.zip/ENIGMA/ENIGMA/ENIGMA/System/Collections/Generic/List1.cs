﻿using System.Windows.Forms;
using ENIGMA;

namespace System.Collections.Generic
{
    internal class List<T1, T2, T3, T4, T5> : ENIGMA.List<int, Keys, Label, Label, int>
    {
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RINGS : MonoBehaviour
{

    public List<int> PierścienPierwszy = new List<int>(new int[] { 20, 5, 25, 13, 8, 21, 15, 12, 1, 14, 7, 2, 22, 24, 3, 4, 16, 11, 6, 0, 17, 23, 18, 9, 19, 10 });
    public List<int> PierścienDrugi = new List<int>(new int[] { 8, 12, 5, 23, 16, 4, 17, 21, 11, 20, 6, 15, 1, 7, 10, 22, 19, 3, 25, 18, 0, 2, 14, 24, 9, 13 });
    public List<int> PierścienTrzeci = new List<int>(new int[] { 2, 15, 10, 14, 19, 4, 20, 0, 5, 9, 23, 3, 18, 11, 24, 1, 25, 8, 16, 7, 12, 21, 17, 13, 22, 6 });

    

    float Angle = 0,Ring1_Angle = 0, Ring2_Angle = 0, Ring3_Angle = 0;

    public GameObject Ring_1, Ring_2, Ring_3;
    MAIN Main;

    public void Start()
    {
        Angle = 360f / 26f;
        Main = GameObject.Find("BUTTONS").GetComponent<MAIN>();
    }

    public void CofnieciePierscienPierwszy()
    {
        int temp = PierścienPierwszy[25];
        PierścienPierwszy.RemoveAt(25);
        PierścienPierwszy.Insert(0, temp);
        Ring1_Angle -= Angle;
        Ring_1.transform.localRotation = Quaternion.Euler(Ring1_Angle, 0, 0);
        //Ring_1.transform.Rotate(-Angle, 0.0f, 0.0f, Space.Self);
    }
    public void CofnieciePierscienDrugi()
    {
        int temp = PierścienDrugi[25];
        PierścienDrugi.RemoveAt(25);
        PierścienDrugi.Insert(0, temp);
        Ring2_Angle -= Angle;
        Ring_2.transform.localRotation = Quaternion.Euler(Ring2_Angle, 0, 0);
        //Ring_2.transform.Rotate(-Angle, 0.0f, 0.0f, Space.Self);
    }
    public void CofnieciePierscienTrzeci()
    {
        int temp = PierścienTrzeci[25];
        PierścienTrzeci.RemoveAt(25);
        PierścienTrzeci.Insert(0, temp);
        Ring2_Angle -= Angle;
        Ring_2.transform.localRotation = Quaternion.Euler(Ring2_Angle, 0, 0);
        //Ring_3.transform.Rotate(-Angle, 0.0f, 0.0f, Space.Self);
    }
    public void PrzesunieciePierscienPierwszy()
    {
        int temp = PierścienPierwszy[0];
        PierścienPierwszy.RemoveAt(0);
        PierścienPierwszy.Add(temp);
        Ring1_Angle += Angle;
        Ring_1.transform.localRotation = Quaternion.Euler(Ring1_Angle, 0, 0);
        //Ring_1.transform.Rotate(Angle, 0.0f, 0.0f, Space.World);
        Debug.Log(Angle);
    }
    public void PrzesunieciePierscienDrugi()
    {
        int temp = PierścienDrugi[0];
        PierścienDrugi.RemoveAt(0);
        PierścienDrugi.Add(temp);
        Ring2_Angle += Angle;
        Ring_2.transform.localRotation = Quaternion.Euler(Ring2_Angle, 0, 0);
        //Ring_2.transform.Rotate(Angle, 0.0f, 0.0f, Space.Self);
    }
    public void PrzesunieciePierscienTrzeci()
    {
        int temp = PierścienTrzeci[0];
        PierścienTrzeci.RemoveAt(0);
        PierścienTrzeci.Add(temp);
        Ring3_Angle += Angle;
        Ring_3.transform.localRotation = Quaternion.Euler(Ring3_Angle, 0, 0);
        //Ring_3.transform.Rotate(Angle, 0.0f, 0.0f, Space.Self);
    }

    public void Cofniecie(int i)
    {
        if (Ring1_Angle < 0)
        {
            if (Ring2_Angle < 0)
            {
                if (Ring3_Angle < 0)
                {
                    //labelPierscien1.Text = (ScrollBarPierscien1.Value = 37).ToString();
                    //labelPierscien2.Text = (ScrollBarPierscien2.Value = 37).ToString();
                    //labelPierscien3.Text = (ScrollBarPierscien3.Value = 37).ToString();
                    //Ring_1.transform.localRotation = Quaternion.Euler(360 - Angle, 0, 0);
                    //Ring_2.transform.localRotation = Quaternion.Euler(360 - Angle, 0, 0);
                    //Ring_3.transform.localRotation = Quaternion.Euler(360 - Angle, 0, 0);

                    Ring1_Angle = 356;
                    Ring2_Angle = 356;
                    Ring3_Angle = 356;

                    CofnieciePierscienPierwszy();
                    CofnieciePierscienDrugi();
                    CofnieciePierscienTrzeci();
                }
                else
                {
                    //labelPierscien1.Text = (ScrollBarPierscien1.Value = 37).ToString();
                    //labelPierscien2.Text = (ScrollBarPierscien2.Value = 37).ToString();
                    //labelPierscien3.Text = (ScrollBarPierscien3.Value -= 1).ToString();
                    //Ring_1.transform.localRotation = Quaternion.Euler(360 - Angle, 0, 0);
                    //Ring_2.transform.localRotation = Quaternion.Euler(360 - Angle, 0, 0);
                    //Ring_3.transform.Rotate(-Angle, 0.0f, 0.0f, Space.Self);

                    Ring1_Angle = 356;
                    Ring2_Angle = 356;

                    CofnieciePierscienPierwszy();
                    CofnieciePierscienDrugi();
                    CofnieciePierscienTrzeci();
                }
            }
            else
            {
                //labelPierscien1.Text = (ScrollBarPierscien1.Value = 37).ToString();
                //labelPierscien2.Text = (ScrollBarPierscien2.Value -= 1).ToString();
                //Ring_1.transform.localRotation = Quaternion.Euler(360 - Angle, 0, 0);
                //Ring_2.transform.Rotate(-Angle, 0.0f, 0.0f, Space.Self);
                Ring1_Angle = 356;

                CofnieciePierscienPierwszy();
                CofnieciePierscienDrugi();
            }
        }
        else
        {
            //labelPierscien1.Text = (ScrollBarPierscien1.Value -= 1).ToString();
            //Ring_1.transform.Rotate(-Angle, 0.0f, 0.0f, Space.Self);

            CofnieciePierscienPierwszy();
        }
        ZapalenieLampki(i);
    }

    public void Przesuniecie(int i)
    {
        

        Debug.Log("");

        if (Ring1_Angle >= 346)
        {
            if (Ring2_Angle >= 346)
            {
                if (Ring3_Angle >= 346)
                {
                    //labelPierscien1.Text = (ScrollBarPierscien1.Value = 1).ToString();
                    //labelPierscien2.Text = (ScrollBarPierscien2.Value = 1).ToString();
                    //labelPierscien3.Text = (ScrollBarPierscien3.Value = 1).ToString();
                    //Ring_1.transform.localRotation = Quaternion.Euler(Angle, 0, 0);
                    ///Ring_2.transform.localRotation = Quaternion.Euler(Angle, 0, 0);
                    //Ring_3.transform.localRotation = Quaternion.Euler(Angle, 0, 0);

                    Ring1_Angle = 0;
                    Ring2_Angle = 0;
                    Ring3_Angle = 0;            

                    PrzesunieciePierscienPierwszy();
                    PrzesunieciePierscienDrugi();
                    PrzesunieciePierscienTrzeci();
                }
                else
                {
                    //labelPierscien1.Text = (ScrollBarPierscien1.Value = 1).ToString();
                    //labelPierscien2.Text = (ScrollBarPierscien2.Value = 1).ToString();
                    //labelPierscien3.Text = (ScrollBarPierscien3.Value += 1).ToString();
                    //Ring_1.transform.localRotation = Quaternion.Euler(Angle, 0, 0);
                    //Ring_2.transform.localRotation = Quaternion.Euler(Angle, 0, 0);
                    //Ring_3.transform.Rotate(Angle, 0.0f, 0.0f, Space.Self);

                    Ring1_Angle = 0; 
                    Ring2_Angle = 0;

                    PrzesunieciePierscienPierwszy();
                    PrzesunieciePierscienDrugi();
                    PrzesunieciePierscienTrzeci();
                }
            }
            else
            {
                //labelPierscien1.Text = (ScrollBarPierscien1.Value = 1).ToString();
                //labelPierscien2.Text = (ScrollBarPierscien2.Value += 1).ToString();
                //Ring_1.transform.localRotation = Quaternion.Euler(Angle, 0, 0);
                //Ring_2.transform.Rotate(Angle, 0.0f, 0.0f, Space.Self);
                PrzesunieciePierscienPierwszy();

                Ring1_Angle = 0;
                //Ring_1.transform.localRotation = Quaternion.Euler(Ring1_Angle, 0, 0);

                //Debug.Log(Ring1_Angle);

                
                PrzesunieciePierscienDrugi();
            }
        }
        else
        {
            //labelPierscien1.Text = (ScrollBarPierscien1.Value += 1).ToString();
            //Ring_1.transform.Rotate(Angle, 0.0f, 0.0f, Space.Self);

            PrzesunieciePierscienPierwszy();
        }
        ZapalenieLampki(i);
    }

    void ZapalenieLampki(int i)
    {
        MeshRenderer test = Main.Lights.transform.GetChild(i).GetComponent<MeshRenderer>();
        test.material = Resources.Load("LIGHTS_KB_ON", typeof(Material)) as Material;
    }
}

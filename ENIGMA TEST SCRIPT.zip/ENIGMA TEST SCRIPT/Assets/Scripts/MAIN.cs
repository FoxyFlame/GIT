﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MAIN : MonoBehaviour
{

    public List<KeyCode> KlawiszePodst  = new List<KeyCode> (new KeyCode[] { KeyCode.A, KeyCode.B, KeyCode.C, KeyCode.D, KeyCode.E, KeyCode.F, KeyCode.G, KeyCode.H, KeyCode.I, KeyCode.J, KeyCode.K, KeyCode.L, KeyCode.M, KeyCode.N, KeyCode.O, KeyCode.P, KeyCode.Q, KeyCode.R, KeyCode.S, KeyCode.T, KeyCode.U, KeyCode.V, KeyCode.W, KeyCode.X, KeyCode.Y, KeyCode.Z });

    bool Nacisk = false, Deszyfracja = false;

    public int przechowanie_i_keydown, ChildCount;

    Vector3 poprzednia_pozycja;

    public GameObject Lights;
    GameObject Player, SzyfrDeszyfr;
    RINGS Rings;

    private void Start()
    {
        SzyfrDeszyfr = GameObject.Find("Syfr_Deszyfr");
        ChildCount = transform.childCount;
        Rings = GameObject.Find("RINGS_OBJ").GetComponent<RINGS>();
    }


    void Update()
    {
        ZmianaDefSzyf();

        for (int i = 0; i < ChildCount; i++)
        {
            WykrycieNacisku(i);
        }
    }

    void WykrycieNacisku(int i)
    {
        if (!Nacisk)
        {
            if (Input.GetKeyDown(KlawiszePodst[i]))
            {
                Nacisk = true;
                przechowanie_i_keydown = i;
                poprzednia_pozycja = transform.GetChild(i).position;
                transform.GetChild(i).position -= new Vector3(0f, 0.5f, 0f);
                //ZapalenieLampki(i);
                if (!Deszyfracja)
                {
                    Rings.Przesuniecie(i);
                }
                else
                {
                    Rings.Cofniecie(i);
                }     
            }
        }

        if (Input.GetKeyUp(KlawiszePodst[przechowanie_i_keydown]))
        {
            transform.GetChild(przechowanie_i_keydown).position = poprzednia_pozycja;
            Nacisk = false;
            GaszenieLampki(przechowanie_i_keydown);
        }
    }

    void ZmianaDefSzyf()
    {   
        // wymyślić zmiane szyfr deszyfr

        Debug.Log(SzyfrDeszyfr.transform.rotation.eulerAngles.magnitude);
        if (Input.GetKeyDown(KeyCode.DownArrow) && Deszyfracja == false)
        {
            Deszyfracja = true;
            SzyfrDeszyfr.transform.Rotate(0, 90, 0, Space.World);
        }

        if (Input.GetKeyDown(KeyCode.UpArrow) && Deszyfracja == true)
        {
            Deszyfracja = false;
            SzyfrDeszyfr.transform.Rotate(0, -90, 0, Space.Self);
        }
    }

    void ZapalenieLampki(int i)
    {
        MeshRenderer test = Lights.transform.GetChild(i).GetComponent<MeshRenderer>();
        test.material = Resources.Load("LIGHTS_KB_ON", typeof(Material)) as Material;
    }

    void GaszenieLampki(int i)
    {
        MeshRenderer test = Lights.transform.GetChild(i).GetComponent<MeshRenderer>();
        test.material = Resources.Load("LIGHTS_KB_OFF", typeof(Material)) as Material;
    }
}
